package com.example.neobar
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS", "android.permission.BLUETOOTH_CONNECT"), 1)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        fun title(t: String) = TextView(this).apply { text = "\n$t"; textSize = 18f }
        fun slider(name: String, key: String, min: Int, max: Int, def: Int, unit: String = "dp") = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val label = TextView(context)
            val sb = SeekBar(context).apply {
                this.max = max - min; progress = prefs.getInt(key, def) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                        label.text = "$name: ${p + min} $unit"; prefs.edit().putInt(key, p + min).apply() }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {}
                })
            }
            label.text = "$name: ${sb.progress + min} $unit"
            addView(label); addView(sb)
        }
        fun toggle(t: String, key: String, def: Boolean) = Switch(this).apply {
            text = t; isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }
        val themeNames = arrayOf("webOS light", "Dark grey", "Black", "Blue", "Green")
        setContentView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            addView(btn("1. Allow draw over other apps") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) })
            addView(btn("2. Allow notification access (left-side icons)") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
            addView(btn("3. Start status bar") {
                if (Settings.canDrawOverlays(this@MainActivity)) startForegroundService(Intent(this@MainActivity, BarService::class.java)) })
            addView(btn("Stop status bar") { stopService(Intent(this@MainActivity, BarService::class.java)) })

            addView(title("Position & size"))
            addView(slider("Vertical offset", "y", 0, 300, 0))
            addView(slider("Horizontal offset", "x", -100, 100, 0))
            addView(slider("Bar height", "h", 16, 60, 26))
            addView(toggle("Put bar at bottom", "bottom", false))

            addView(title("Show / hide"))
            addView(toggle("Notification icons", "show_notif", true))
            addView(toggle("Clock", "show_clock", true))
            addView(toggle("Bluetooth", "show_bt", true))
            addView(toggle("3G / data", "show_net", true))
            addView(toggle("Signal", "show_sig", true))
            addView(toggle("Battery", "show_batt", true))
            addView(slider("Max notification icons", "max_icons", 1, 12, 6, "icons"))

            addView(title("Look"))
            addView(Spinner(context).apply {
                adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, themeNames)
                setSelection(prefs.getInt("theme", 0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (pos != prefs.getInt("theme", 0)) prefs.edit().putInt("theme", pos).apply() }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
            addView(slider("Opacity", "alpha", 20, 100, 100, "%"))
            addView(slider("Clock text size", "clock_size", 9, 22, 13, "sp"))
            addView(toggle("24-hour clock", "h24", true))
            addView(toggle("Show date", "show_date", true))
        }) })
    }
}
