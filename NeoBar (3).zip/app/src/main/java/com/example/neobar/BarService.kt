package com.example.neobar
import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.*
import android.net.*
import android.os.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class BarService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bar: LinearLayout
    private lateinit var left: LinearLayout
    private lateinit var clock: TextView
    private lateinit var bt: ImageView; private lateinit var net: ImageView
    private lateinit var sig: ImageView; private lateinit var batt: ImageView
    private lateinit var lp: WindowManager.LayoutParams
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }
    private val h = Handler(Looper.getMainLooper())
    private var fmt = SimpleDateFormat("MMM d  HH:mm", Locale.getDefault())
    private var lastIcons: List<Drawable> = emptyList()
    // bar top, bar bottom, text/icon colour
    private val themes = arrayOf(
        intArrayOf(0xFFF4F4F4.toInt(), 0xFFC9C9C9.toInt(), 0xFF333333.toInt()),
        intArrayOf(0xFF4A4A4A.toInt(), 0xFF1C1C1C.toInt(), 0xFFEEEEEE.toInt()),
        intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF4FA3E0.toInt(), 0xFF1F5E99.toInt(), 0xFFFFFFFF.toInt()),
        intArrayOf(0xFF7ED957.toInt(), 0xFF2E8B2E.toInt(), 0xFF102010.toInt()))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun res(n: String) = resources.getIdentifier(n, "drawable", packageName)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("bar", "Status bar", NotificationManager.IMPORTANCE_MIN)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        startForeground(1, Notification.Builder(this, "bar").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("NeoBar running").build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
            // webOS-style light gradient
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFF4F4F4.toInt(), 0xFFC9C9C9.toInt()))
        }
        left = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        clock = TextView(this).apply { setTextColor(0xFF333333.toInt()); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(6), 0, 0, 0) }
        fun icon(w: Int, hh: Int) = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), dp(hh)).apply { marginStart = dp(5) } }
        bt = icon(16, 18).apply { setImageResource(res("ic_bt")) }
        net = icon(18, 18).apply { setImageResource(res("ic_3g")) }
        sig = icon(20, 16).apply { setImageResource(res("ic_signal")) }
        batt = icon(38, 18)
        bar.addView(left); bar.addView(clock)
        bar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        listOf(bt, net, sig, batt).forEach { bar.addView(it) }

        lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, dp(26),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP }
        applyPrefs()
        wm.addView(bar, lp)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)

        registerReceiver(object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = updBattery(i) },
            IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        NotifService.onChange = { icons -> h.post { showIcons(icons) } }
        tick()
    }

    private fun applyPrefs() {
        lp.height = dp(prefs.getInt("h", 26))
        lp.gravity = if (prefs.getBoolean("bottom", false)) Gravity.BOTTOM else Gravity.TOP
        lp.x = dp(prefs.getInt("x", 0))
        lp.y = dp(prefs.getInt("y", 0))
        fun vis(k: String) = if (prefs.getBoolean(k, true)) View.VISIBLE else View.GONE
        bt.visibility = vis("show_bt"); net.visibility = vis("show_net"); sig.visibility = vis("show_sig")
        batt.visibility = vis("show_batt"); clock.visibility = vis("show_clock")
        val th = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        bar.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(th[0], th[1]))
        bar.alpha = prefs.getInt("alpha", 100) / 100f
        clock.setTextColor(th[2]); clock.textSize = prefs.getInt("clock_size", 13).toFloat()
        fmt = SimpleDateFormat((if (prefs.getBoolean("show_date", true)) "MMM d  " else "") +
            (if (prefs.getBoolean("h24", true)) "HH:mm" else "h:mm a"), Locale.getDefault())
        clock.text = fmt.format(Date())
        showIcons(lastIcons)
        if (bar.isAttachedToWindow) wm.updateViewLayout(bar, lp)
    }

    // Battery sprite: 110 frames (0..109) sliced from the sheet -> map 0-100%
    private fun updBattery(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        batt.setImageResource(res("bat_%03d".format(lvl * 109 / 100)))
    }

    private fun showIcons(icons: List<Drawable>) {
        lastIcons = icons
        left.removeAllViews()
        left.visibility = if (prefs.getBoolean("show_notif", true)) View.VISIBLE else View.GONE
        val tint = themes[prefs.getInt("theme", 0).coerceIn(0, themes.size - 1)][2]
        icons.take(prefs.getInt("max_icons", 6)).forEach { d ->
            left.addView(ImageView(this).apply {
                setImageDrawable(d.constantState?.newDrawable()?.mutate() ?: d); setColorFilter(tint)
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(3) } })
        }
    }

    private fun tick() {
        clock.text = fmt.format(Date())
        val cm = getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork)
        net.alpha = if (c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) 1f else 0.3f
        sig.alpha = if (c != null) 1f else 0.3f
        val ad = BluetoothAdapterHelper.on(this); bt.alpha = if (ad) 1f else 0.3f
        h.postDelayed({ tick() }, 15000)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); prefs.unregisterOnSharedPreferenceChangeListener(prefListener); NotifService.onChange = null; wm.removeView(bar); super.onDestroy() }
}

object BluetoothAdapterHelper {
    fun on(c: Context) = runCatching { c.getSystemService(android.bluetooth.BluetoothManager::class.java).adapter?.isEnabled == true }.getOrDefault(false)
}
